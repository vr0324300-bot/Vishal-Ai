plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "com.vishalai.app"; compileSdk = 35
 defaultConfig { applicationId = "com.vishalai.app"; minSdk = 24; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}

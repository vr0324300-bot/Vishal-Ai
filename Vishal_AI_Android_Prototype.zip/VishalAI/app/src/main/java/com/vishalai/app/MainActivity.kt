package com.vishalai.app
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
class MainActivity: Activity(){
 private lateinit var chat:LinearLayout; private lateinit var input:EditText
 override fun onCreate(b:Bundle?){super.onCreate(b); val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(24,28,24,18)
  val title=TextView(this); title.text="🤖 Vishal AI"; title.textSize=28f; title.gravity=Gravity.CENTER; title.setTextColor(Color.rgb(45,35,65)); root.addView(title,LinearLayout.LayoutParams(-1,-2))
  chat=LinearLayout(this); chat.orientation=LinearLayout.VERTICAL; val scroll=ScrollView(this); scroll.addView(chat); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
  val row=LinearLayout(this); input=EditText(this); input.hint="Vishal AI se kuch puchho..."; input.setSingleLine(true); val send=Button(this); send.text="Send"; send.setOnClickListener{sendMessage()}; row.addView(input,LinearLayout.LayoutParams(0,-2,1f)); row.addView(send); root.addView(row); setContentView(root); add("Vishal AI","Namaste Vishal! 👋 Main tumhara AI assistant hoon.") }
 private fun sendMessage(){val q=input.text.toString().trim(); if(q.isEmpty())return; add("Tum",q); input.setText(""); add("Vishal AI","Maine tumhari baat samajhi: \"$q\"\n\nReal AI API connect karne par main intelligent jawab de sakunga.")}
 private fun add(w:String,t:String){val v=TextView(this); v.text="$w: $t"; v.textSize=17f; v.setPadding(14,12,14,12); chat.addView(v)}
}
